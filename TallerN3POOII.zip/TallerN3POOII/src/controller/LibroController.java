package controller;

import dao.LibroDAO;
import dao.impl.LibroDAOImpl;
import model.Libro;

import java.sql.SQLException;
import java.util.List;

public class LibroController {

    private final LibroDAO libroDAO;

    public LibroController() {
        this.libroDAO = new LibroDAOImpl();
    }

    public boolean guardar(Libro libro) throws SQLException {
        if(libro.getTitulo().isEmpty() || libro.getAutor().isEmpty()){
            return false;
        }
        return libroDAO.create(libro);
    }

    public List<Libro> listar() throws SQLException{
        return libroDAO.readALL();
    }

    public boolean actualizar(Libro libro) throws SQLException{
        if(libro.getTitulo().isEmpty() || libro.getAutor().isEmpty()){
            return false;
        }
        return libroDAO.update(libro);
    }

    public boolean eliminar(int id) throws SQLException{
        if(id > 0){
            return libroDAO.delete(id);
        }
        return false;
    }

}
