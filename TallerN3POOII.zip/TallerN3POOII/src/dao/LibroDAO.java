package dao;

import model.Libro;

import java.sql.SQLException;
import java.util.List;

public interface LibroDAO {

    // Mostramos que operaciones se podran realizar sobre LIBRO.

    // CRUD --> CREATE, READ, UPDATE y DELETE

    // CREATE
    boolean create(Libro libro) throws SQLException;

    // READ
    List<Libro> readALL() throws SQLException;

    // UPDATE
    boolean update(Libro libro) throws SQLException;

    // DELETE
    boolean delete(int id) throws SQLException;


}
