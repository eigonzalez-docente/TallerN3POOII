package dao.impl;

import dao.LibroDAO;
import model.Libro;
import util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroDAOImpl implements LibroDAO {
    @Override
    public boolean create(Libro libro) throws SQLException {

        String sql = "INSERT INTO libro(titulo, autor, disponible) VALUES (?, ?, ?)";


        try (Connection con = ConexionBD.getInstance().conectar()){
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setBoolean(3, libro.isDisponible());

            // executeUpdate() retorna cuantas filas fueron afectadas.
            return ps.executeUpdate() > 0;
        }

    }

    @Override
    public List<Libro> readALL() throws SQLException {

        String sql = "SELECT id, titulo, autor, disponible FROM libro ORDER BY id";

        List<Libro> libros = new ArrayList<>();

        try (Connection con = ConexionBD.getInstance().conectar()){
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                Libro libro = new Libro(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getBoolean("disponible")
                );

                libros.add(libro);
            }
        }

        return libros;
    }

    @Override
    public boolean update(Libro libro) throws SQLException {
        String sql = "UPDATE libro SET titulo=?, autor=?, disponible=? WHERE id=?";

        try (Connection con = ConexionBD.getInstance().conectar()){
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setBoolean(3, libro.isDisponible());
            ps.setInt(4, libro.getId());

            return ps.executeUpdate() > 0; // ROWS
        }
    }

    @Override
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM libro WHERE id=?";

        try (Connection con = ConexionBD.getInstance().conectar()){
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
