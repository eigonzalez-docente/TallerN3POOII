package view;

import controller.LibroController;
import model.Libro;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * VISTA PRINCIPAL DEL TALLER
 * ------------------------------------------------------------
 * Esta ventana permite realizar un CRUD completo de Libro:
 *   C -> Guardar
 *   R -> Listar
 *   U -> Actualizar
 *   D -> Eliminar
 *
 * La parte visual se encuentra también en LibroForm.form y puede editarse
 * gráficamente utilizando Swing UI Designer en IntelliJ IDEA.
 */
public class LibroForm extends JFrame {

    // Componentes vinculados con LibroForm.form.
    private JPanel panelPrincipal;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JComboBox<String> cmbDisponible;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnRefrescar;
    private JTable tblLibros;
    private JLabel lblSeleccion;
    private JLabel lblEstado;

    /*
     * La Vista conversa con el Controller.
     * No creamos un LibroDAOImpl directamente aquí porque queremos mantener
     * separadas las responsabilidades de MVC.
     */
    private final LibroController libroController = new LibroController();

    // Modelo utilizado por JTable para definir columnas y filas.
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Título", "Autor", "Disponible"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    // Guarda el id de la fila seleccionada. -1 significa "ninguna selección".
    private int idSeleccionado = -1;

    public LibroForm() {
        setTitle("AulaLibro - CRUD de Libro");
        setContentPane(panelPrincipal);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(760, 540));
        pack();
        setLocationRelativeTo(null);

        tblLibros.setModel(modeloTabla);

        configurarEventos();
        cargarLibrosEnSegundoPlano();
    }

    /**
     * EVENTOS DE LOS BOTONES
     * ------------------------------------------------------------
     * En Swing utilizamos ActionListener para indicar qué debe ocurrir
     * cuando el usuario presiona un botón.
     */
    private void configurarEventos() {
        btnGuardar.addActionListener(e -> guardarLibro());
        btnActualizar.addActionListener(e -> actualizarLibro());
        btnEliminar.addActionListener(e -> eliminarLibro());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnRefrescar.addActionListener(e -> cargarLibrosEnSegundoPlano());

        /*
         * Cuando el estudiante selecciona una fila, copiamos sus datos hacia
         * los controles del formulario. Esto permite editar o eliminar ese libro.
         */
        tblLibros.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tblLibros.getSelectedRow() >= 0) {
                cargarFilaSeleccionada();
            }
        });
    }

    // ============================================================
    // CREATE - GUARDAR
    // ============================================================
    private void guardarLibro() {
        if (!validarFormulario()) {
            return;
        }

        // Creamos un objeto Libro con la información ingresada en la Vista.
        Libro libro = new Libro(
                txtTitulo.getText().trim(),
                txtAutor.getText().trim(),
                cmbDisponible.getSelectedIndex() == 0
        );

        try {
            // La Vista llama al Controller; el Controller continúa el flujo.
            if (libroController.guardar(libro)) {
                mostrarMensaje("Libro registrado correctamente.", JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();
                cargarLibrosEnSegundoPlano();
            }
        } catch (SQLException ex) {
            mostrarErrorSQL("No fue posible registrar el libro", ex);
        }
    }

    // ============================================================
    // READ - LISTAR
    // ============================================================
    /**
     * EJEMPLO SIMPLE DE SWINGWORKER
     * ------------------------------------------------------------
     * Una consulta a BD puede tardar. Si la ejecutamos directamente en el
     * hilo de la interfaz, la ventana podría dejar de responder temporalmente.
     *
     * doInBackground(): realiza la consulta en segundo plano.
     * done(): se ejecuta cuando la tarea termina y actualiza la interfaz.
     *
     * En este taller SwingWorker se utiliza solo para mostrar el concepto
     * sin agregar más modelos ni procesos complejos.
     */
    private void cargarLibrosEnSegundoPlano() {
        btnRefrescar.setEnabled(false);
        lblEstado.setText("Estado: consultando libros...");

        SwingWorker<List<Libro>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Libro> doInBackground() throws Exception {
                return libroController.listar();
            }

            @Override
            protected void done() {
                try {
                    actualizarTabla(get());
                    lblEstado.setText("Estado: libros cargados correctamente.");
                } catch (Exception ex) {
                    mostrarError("No fue posible consultar los libros", ex);
                    lblEstado.setText("Estado: error al consultar libros.");
                } finally {
                    btnRefrescar.setEnabled(true);
                }
            }
        };

        // execute() inicia el SwingWorker.
        worker.execute();
    }

    /** Recibe la lista de libros y la muestra en JTable. */
    private void actualizarTabla(List<Libro> libros) {
        modeloTabla.setRowCount(0);

        for (Libro libro : libros) {
            modeloTabla.addRow(new Object[]{
                    libro.getId(),
                    libro.getTitulo(),
                    libro.getAutor(),
                    libro.isDisponible() ? "Sí" : "No"
            });
        }
    }

    // ============================================================
    // UPDATE - ACTUALIZAR
    // ============================================================
    private void actualizarLibro() {
        if (idSeleccionado == -1) {
            mostrarMensaje("Primero selecciona un libro de la tabla.", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!validarFormulario()) {
            return;
        }

        Libro libro = new Libro(
                idSeleccionado,
                txtTitulo.getText().trim(),
                txtAutor.getText().trim(),
                cmbDisponible.getSelectedIndex() == 0
        );

        try {
            if (libroController.actualizar(libro)) {
                mostrarMensaje("Libro actualizado correctamente.", JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();
                cargarLibrosEnSegundoPlano();
            }
        } catch (SQLException ex) {
            mostrarErrorSQL("No fue posible actualizar el libro", ex);
        }
    }

    // ============================================================
    // DELETE - ELIMINAR
    // ============================================================
    private void eliminarLibro() {
        if (idSeleccionado == -1) {
            mostrarMensaje("Primero selecciona un libro de la tabla.", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Antes de eliminar pedimos confirmación para evitar borrados accidentales.
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Eliminar el libro seleccionado?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (libroController.eliminar(idSeleccionado)) {
                mostrarMensaje("Libro eliminado correctamente.", JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();
                cargarLibrosEnSegundoPlano();
            }
        } catch (SQLException ex) {
            mostrarErrorSQL("No fue posible eliminar el libro", ex);
        }
    }

    // ============================================================
    // VALIDACIONES Y APOYO A LA INTERFAZ
    // ============================================================
    private boolean validarFormulario() {
        String titulo = txtTitulo.getText().trim();
        String autor = txtAutor.getText().trim();

        if (titulo.isEmpty() || autor.isEmpty()) {
            mostrarMensaje("Título y autor son obligatorios.", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (titulo.length() > 120) {
            mostrarMensaje("El título no puede superar 120 caracteres.", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (autor.length() > 100) {
            mostrarMensaje("El autor no puede superar 100 caracteres.", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    /** Copia los datos de la fila seleccionada hacia los controles. */
    private void cargarFilaSeleccionada() {
        int fila = tblLibros.getSelectedRow();

        idSeleccionado = (int) modeloTabla.getValueAt(fila, 0);
        txtTitulo.setText(modeloTabla.getValueAt(fila, 1).toString());
        txtAutor.setText(modeloTabla.getValueAt(fila, 2).toString());
        cmbDisponible.setSelectedIndex(
                "Sí".equals(modeloTabla.getValueAt(fila, 3)) ? 0 : 1
        );

        lblSeleccion.setText("Libro seleccionado: ID " + idSeleccionado);
    }

    private void limpiarFormulario() {
        idSeleccionado = -1;
        txtTitulo.setText("");
        txtAutor.setText("");
        cmbDisponible.setSelectedIndex(0);
        tblLibros.clearSelection();
        lblSeleccion.setText("Selecciona una fila para editar o eliminar");
        txtTitulo.requestFocus();
    }

    private void mostrarMensaje(String mensaje, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, "AulaLibro", tipo);
    }

    private void mostrarErrorSQL(String contexto, SQLException ex) {
        JOptionPane.showMessageDialog(
                this,
                contexto + ".\nDetalle: " + ex.getMessage(),
                "Error de base de datos",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void mostrarError(String contexto, Exception ex) {
        Throwable causa = ex.getCause() != null ? ex.getCause() : ex;

        JOptionPane.showMessageDialog(
                this,
                contexto + ".\nDetalle: " + causa.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
